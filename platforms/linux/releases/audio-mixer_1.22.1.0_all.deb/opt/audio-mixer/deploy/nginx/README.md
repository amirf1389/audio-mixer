# nginx proxy for Audio Mixer

`audio-mixer.conf` puts nginx in front of the mixer page and the local Node bridge:
HTTPS (TLS 1.2/1.3, HSTS), security headers, gzip, rate limiting, WebSocket upgrade for `/ws/output`,
and no exposure of dotfiles, bridge sources or repo metadata.

## Install (Linux)
    sudo cp deploy/nginx/audio-mixer.conf /etc/nginx/conf.d/audio-mixer.conf
    # edit: server_name, ssl_certificate(_key) (e.g. certbot), root /srv/audio-mixer -> your checkout
    sudo nginx -t && sudo nginx -s reload
    cd bridge && BRIDGE_HOSTS=mixer.example.com BRIDGE_ORIGINS=https://mixer.example.com node server.js

`BRIDGE_HOSTS` / `BRIDGE_ORIGINS` are needed on whichever machine runs the bridge behind nginx, because nginx
forwards the public `Host` and the page's `Origin`; the bridge otherwise only accepts localhost.

## Basic auth for the bridge
`/api/` and `/ws/output` require a username and password **in addition to** the IP rule (`satisfy all`).
Create the user file (nginx supports `openssl passwd -apr1`, or bcrypt via `htpasswd -B` from apache2-utils):

    sudo sh -c 'echo "mixer:$(openssl passwd -apr1)" > /etc/nginx/.htpasswd_mixer'   # asks for the password
    sudo chmod 640 /etc/nginx/.htpasswd_mixer && sudo chgrp www-data /etc/nginx/.htpasswd_mixer
    sudo nginx -t && sudo nginx -s reload

Add more users with `>>`. Credentials are not forwarded to the bridge, and repeated attempts hit the rate limit.
Over plain HTTP basic auth is readable on the wire, so keep it behind the HTTPS server block.
The first bridge request makes the browser ask for the login; if your browser does not reuse it for the
WebSocket, open `https://your-host/api/status` once in the same tab and sign in, then reload the mixer.

## Rate limiting and ban protection (fail2ban / guard)
**Rate limits (already in `audio-mixer.conf`)**: `/api` and `/ws` 10 req/s per IP (burst 20 / 5), the page 20 req/s (burst 40),
40 simultaneous connections per IP. Anything over the limit gets **HTTP 429**.

**Bans**: clients that keep failing (wrong password 401, blocked 403, rate limited 429, or probing `/.git`, `/bridge/`,
`/deploy/` with 404) are banned after 10 hits in 10 minutes for 1 hour (fail2ban doubles repeat offenders).
Linux uses real **fail2ban** (`fail2ban/`). Everywhere fail2ban cannot run, `guard.sh` does the same job in plain shell by
writing `deny <ip>;` to a file nginx includes. `setup.sh` picks the right one for the terminal you run it in:

| Terminal | Command | Protection |
| --- | --- | --- |
| Linux (apt/dnf/yum/pacman/zypper/apk) | `sudo sh deploy/nginx/setup.sh` | fail2ban jails `audio-mixer-bridge`, `nginx-http-auth`, `nginx-limit-req` |
| Windows with WSL2 (recommended) | `wsl --install`, then in the Linux terminal: `sudo sh deploy/nginx/setup.sh` | fail2ban (guard if WSL has no systemd) |
| Windows Git Bash (native nginx) | `sh deploy/nginx/setup.sh` shows the exact `export` lines, then `sh deploy/nginx/guard.sh run` | guard |
| macOS Terminal | `sh deploy/nginx/setup.sh` (needs Homebrew), then `sudo audio-mixer-guard run &` | guard |
| Android (Termux) | `sh deploy/nginx/setup.sh`, then `termux-wake-lock; nohup audio-mixer-guard run >/dev/null 2>&1 &` | guard |
| iOS (iSH) | `sh deploy/nginx/setup.sh`, then `audio-mixer-guard run &` (iOS suspends background apps: only active while iSH is open) | guard |

`sh deploy/nginx/setup.sh --dry-run` prints what it would do without changing anything. The installed `audio-mixer.conf`
uses your platform's nginx paths but is **not** activated: edit the `CHANGE ME` lines, include it from your `http { }`
block, then `nginx -t && nginx -s reload`.

Day to day:

    sudo fail2ban-client status audio-mixer-bridge                 # Linux: who is banned
    sudo fail2ban-client set audio-mixer-bridge unbanip 203.0.113.5
    audio-mixer-guard list                                          # guard: active bans
    audio-mixer-guard unban 203.0.113.5

Tuning for guard: `GUARD_MAXRETRY` (10), `GUARD_FINDTIME` (600 s), `GUARD_BANTIME` (3600 s), `GUARD_IGNORE` (default
`127.0.0.1 ::1`; add your admin addresses, never lock yourself out). For fail2ban edit `maxretry/findtime/bantime/ignoreip`
in `/etc/fail2ban/jail.d/audio-mixer.local`. If another proxy or CDN sits in front of nginx, configure `real_ip_header`
first, otherwise the proxy's address (not the visitor's) is what gets banned.

## Docker (Linux)
    docker compose -f deploy/nginx/docker-compose.yml up -d
The compose file uses host networking so nginx can reach the bridge on `127.0.0.1:8765`.
Put the auth file at `deploy/nginx/.htpasswd_mixer` (`echo "mixer:$(openssl passwd -apr1)" > deploy/nginx/.htpasswd_mixer`), mount your certificates at `./certs` (`fullchain.pem`, `privkey.pem`) and adjust `server_name`.

## How the page finds the bridge
The page (`connectBridge()`) tries `location.origin` only when the hostname is `localhost` / `127.0.0.1`, then
`http://localhost:8765`. So:
- **Public domain:** nginx serves the page; each visitor's browser looks for a bridge on *their own* PC
  (`http://localhost:8765`). That PC must start its bridge with `BRIDGE_ORIGINS=https://mixer.example.com`.
  The `/api` and `/ws` proxy blocks are not used by remote visitors (and stay refused for them).
- **Same machine (`https://localhost`, `server_name localhost`):** the page talks to the bridge through nginx, so
  `/api/drivers` and `/ws/output` go through the proxy (rate limited, TLS, WebSocket upgrade).

## Important: who can use the bridge
The bridge reports and drives the audio hardware of the machine it runs on. The config therefore only lets
`127.0.0.1` / `::1` reach `/api/` and `/ws/output` (add your LAN in the `allow` lines if you trust it). Anyone else
can load the page but gets 403 from those two paths and the page falls back to plain Web Audio, as without a bridge.
For a remote bridge, put authentication (basic auth / mTLS / VPN) in front first.

## Verify
    sudo nginx -t
    curl -sI https://mixer.example.com/ | grep -i -E "strict|x-frame|nosniff"
    curl -s -o /dev/null -w "%{http_code}\n" https://mixer.example.com/bridge/server.js   # 404
    node bridge/audit.js --url http://127.0.0.1:8765

## Tested
Validated with nginx 1.24 (`nginx -t`) against the real bridge: page 200 with HSTS / nosniff / X-Frame-Options /
Permissions-Policy, gzip, HTTP→HTTPS redirect, 404 for `/bridge/*`, `/.git/*`, `/.github/*`, `*.md`, `*.json`,
403 for POST and for foreign origins, basic auth on `/api` and `/ws/output` (401 without / with wrong credentials, 200 and WebSocket 101 with the right ones; the page itself stays public), `/api` and the page rate limited (HTTP 429 beyond the burst), WebSocket upgrade 101.
The fail2ban filter was checked with `fail2ban-regex` (matches 401/403/429 bridge hits, scanner 404s, IPv6 and logins with
spaces; ignores 200s and ordinary 404s). `guard.sh` was run against real nginx: 6 bad requests → ban → nginx answers 403 →
unban / expiry restore access; hostile "client addresses" (`;`, `$()`, backticks, `}`) are rejected before reaching the config.

## Keys website + public key API (`keys-api.conf`)
Puts the customer key page (`deploy/website/license.html`) and the Key Generator's public API behind HTTPS at
`https://amirfakhri.interactivelink.site` (change the domain on the `CHANGE ME` lines):

| URL | Goes to |
| --- | --- |
| `/keys` | the key request page (static file) |
| `POST /request-license` | copies older than 1.22.1.0 only: answered 410 (buy on WhatsApp) unless the generator runs with `--accept-requests`; then its inbox (8 KB max, 6/min per IP at nginx, 5/day per sender) |
| `/update.json`, `/vendor.json`, `/releases/<file>` | OTA updates published by the generator |
| anything else | 404 (the vendor page with keys and PIN is **never** proxied) |

    sudo mkdir -p /srv/amfx1-website && sudo cp deploy/website/license.html /srv/amfx1-website/
    sudo cp deploy/nginx/keys-api.conf /etc/nginx/conf.d/ && sudo cp deploy/nginx/keys-api-proxy.inc /etc/nginx/
    sudo certbot certonly --webroot -w /var/www/letsencrypt -d amirfakhri.interactivelink.site
    sudo nginx -t && sudo nginx -s reload
    "AmF X1 Key Generator.exe"          # 127.0.0.1:8780 is the default since 1.22.0.1 (security fix, Nov 2026); or: node scripts/license-generator.js --public

With `--public-bind 127.0.0.1` the generator's port 8780 is reachable only from nginx on the same computer: forward
TCP **443** (and 80 for certificate renewal) on the router instead of 8780. The generator then takes the customer's
address from nginx's `X-Real-IP` (only from a loopback connection, so it cannot be faked from outside).
The page posts nothing: its BUY buttons open WhatsApp (wa.me/601120871185) with the edition and the machine code from the address.
