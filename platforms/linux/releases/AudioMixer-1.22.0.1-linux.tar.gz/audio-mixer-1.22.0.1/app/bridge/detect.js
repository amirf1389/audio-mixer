'use strict';
const nativeEngine = require('./native-engine');
const { detectAudify } = require('./audify');
// Native audio driver / device detection. Read-only; every probe is optional and fails soft.
const { execFile } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const winnative = require('./winnative');
const sysaudio = require('./sysaudio');

function run(cmd, args, timeout = 4000) {
  return new Promise(resolve => {
    execFile(cmd, args, { timeout, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout) => resolve(err ? '' : String(stdout)));
  });
}

// Like run(), but says why there was no output: a key that does not exist (reg.exe exits 1 at once) is an answer, a timeout or a launch failure is not.
function runInfo(cmd, args, timeout) {
  return new Promise(resolve => {
    execFile(cmd, args, { timeout, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout) => resolve({ out: String(stdout || ''), failed: !!err && !!(err.killed || err.signal || err.code === 'ENOENT' || err.code === 'EACCES'), err }));
  });
}

// The ASIO drivers registered on this PC. HKLM\SOFTWARE\ASIO has two views on 64-bit Windows: 64-bit drivers (read with /reg:64) and 32-bit drivers (WOW6432Node, /reg:32); a 64-bit
// server that reads only its own view never saw a 32-bit driver, and a probe that timed out (a busy PC) made every driver vanish for one scan. Both views are read, a failed read is
// tried once more, and when it still fails the drivers seen in the last ten minutes are kept (marked `stale`). Drivers of the other bitness than this process are listed in
// `wrongBitness`: they exist, but a 32-bit driver cannot be loaded into a 64-bit server (and the other way round).
const asioMemory = { at: 0, names: [], bits: {} };
const parseAsioKeys = text => String(text).split(/\r?\n/).map(l => (l.match(/HKEY_LOCAL_MACHINE\\SOFTWARE\\(?:WOW6432Node\\)?ASIO\\(.+)$/i) || [])[1]).filter(Boolean).map(n => n.trim()).filter(Boolean);
async function readAsioRegistry({ runner = runInfo, now = Date.now, arch = process.arch, memory = asioMemory, timeout = 8000 } = {}) {
  const names = [], bits = {}; let failed = false;
  for (const view of ['64', '32']) {
    let r = await runner('reg', ['query', 'HKLM\\SOFTWARE\\ASIO', '/reg:' + view], timeout);
    if (r.failed) r = await runner('reg', ['query', 'HKLM\\SOFTWARE\\ASIO', '/reg:' + view], timeout);      // once more: a probe that timed out is not an empty list
    if (r.failed) { failed = true; continue; }
    for (const n of parseAsioKeys(r.out)) { if (!names.includes(n)) names.push(n); (bits[n] = bits[n] || []).includes(Number(view)) || bits[n].push(Number(view)); }
  }
  let stale = false;
  if (!names.length && failed && memory.names.length && now() - memory.at < 10 * 60 * 1000) { names.push(...memory.names); Object.assign(bits, memory.bits); stale = true; }
  else if (!failed || names.length) { memory.at = now(); memory.names = names.slice(); memory.bits = JSON.parse(JSON.stringify(bits)); }
  const mine = arch === 'ia32' || arch === 'x86' || arch === 'arm' ? 32 : 64;
  return { names, bits, stale, wrongBitness: names.filter(n => !bits[n].includes(mine)) };
}

// Keys match the driver ids used by window.universalAsioSdk.drivers in the page.
async function windows() {
  const drivers = new Set(['wasapi-shared', 'wasapi-excl', 'wasapi-loop', 'directsound', 'wdmks', 'mme']);
  const devices = [];
  const asio = [];
  const ps = await run('powershell', ['-NoProfile', '-Command',
    'Get-CimInstance Win32_SoundDevice | Select-Object Name,Manufacturer,Status | ConvertTo-Json -Compress']);
  try {
    const j = JSON.parse(ps || '[]');
    (Array.isArray(j) ? j : [j]).forEach(d => d && d.Name && devices.push({ name: d.Name, vendor: d.Manufacturer || '', status: d.Status || '' }));
  } catch (_) { /* ignore */ }
  if (!devices.length) (await winnative.listWmi()).forEach(d => devices.push(d));   // PowerShell blocked: VBScript + WMI
  const reg = await readAsioRegistry();
  asio.push(...reg.names);
  asio.forEach(n => {
    drivers.add('steinberg');
    const l = n.toLowerCase();
    if (l.includes('asio4all')) drivers.add('asio4all');
    if (l.includes('flexasio')) drivers.add('flexasio');
    if (l.includes('focusrite')) drivers.add('focusrite');
    if (l.includes('yamaha') || l.includes('steinberg')) drivers.add('yamaha');
    if (l.includes('rme') || l.includes('fireface') || l.includes('hammerfall')) drivers.add('rme');
    if (l.includes('motu')) drivers.add('motu');
    if (l.includes('wing') || l.includes('behringer')) drivers.add('wing');
    if (l.includes('apollo') || l.includes('universal audio')) drivers.add('uad');
    if (l.includes('ssl')) drivers.add('ssl');
    if (l.includes('cwasio')) drivers.add('cwasio');
  });
  return { drivers: [...drivers], devices, asio, asioBits: reg.bits, ...(reg.wrongBitness.length ? { asioWrongBitness: reg.wrongBitness } : {}), ...(reg.stale ? { asioStale: true } : {}), recommended: asio.length ? 'steinberg' : 'wasapi-excl' };
}

async function mac() {
  const out = await run('system_profiler', ['SPAudioDataType']);
  const devices = [];
  out.split('\n').forEach(l => { const m = l.match(/^\s{8}([^\s].*):$/); if (m) devices.push({ name: m[1], vendor: '', status: 'OK' }); });
  return { drivers: ['coreaudio'], devices, asio: [], recommended: 'coreaudio' };
}

async function linux() {
  const drivers = new Set();
  const devices = [];
  let cards = '';
  try { cards = fs.readFileSync('/proc/asound/cards', 'utf8'); } catch (_) { /* no ALSA */ }
  cards.split('\n').forEach(l => { const m = l.match(/^\s*\d+\s+\[(\S+)\s*\]:\s*(.+)$/); if (m) devices.push({ name: m[2].trim(), vendor: '', status: 'OK' }); });
  if (cards.trim()) drivers.add('alsa');
  const pw = await run('pw-cli', ['info', '0']);
  const pa = await run('pactl', ['info']);
  if (pw || /PipeWire/i.test(pa)) drivers.add('pipewire');
  if (pa && !/PipeWire/i.test(pa)) drivers.add('pulseaudio');
  const jack = await run('jack_lsp', []);
  if (jack) drivers.add('jack');
  const rec = drivers.has('pipewire') ? 'pipewire' : drivers.has('jack') ? 'jack' : drivers.has('pulseaudio') ? 'pulseaudio' : drivers.has('alsa') ? 'alsa' : null;
  return { drivers: [...drivers], devices, asio: [], recommended: rec };
}

// VST2 / VST3 plugin scan (standard install folders, depth <= 2, capped).
function vstDirs() {
  const h = os.homedir();
  if (process.platform === 'win32') {
    const pf = process.env.ProgramFiles || 'C:\\Program Files';
    const cf = process.env.CommonProgramFiles || path.join(pf, 'Common Files');
    return { vst3: [path.join(cf, 'VST3')], vst2: [path.join(pf, 'VSTPlugins'), path.join(pf, 'Steinberg', 'VSTPlugins'), path.join(cf, 'VST2')] };
  }
  if (process.platform === 'darwin') {
    return { vst3: ['/Library/Audio/Plug-Ins/VST3', path.join(h, 'Library/Audio/Plug-Ins/VST3')], vst2: ['/Library/Audio/Plug-Ins/VST', path.join(h, 'Library/Audio/Plug-Ins/VST')] };
  }
  return { vst3: [path.join(h, '.vst3'), '/usr/lib/vst3', '/usr/local/lib/vst3'], vst2: [path.join(h, '.vst'), '/usr/lib/vst', '/usr/local/lib/vst'] };
}

function scanVst(dirs, ext, max = 500) {
  const found = [];
  const walk = (dir, depth) => {
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { return; }
    for (const e of entries) {
      if (found.length >= max) return;
      const p = path.join(dir, e.name);
      if (e.name.toLowerCase().endsWith(ext)) found.push(e.name.slice(0, -ext.length));
      else if (e.isDirectory() && depth < 2) walk(p, depth + 1);
    }
  };
  dirs.forEach(d => walk(d, 0));
  return found;
}

function detectVst() {
  const d = vstDirs();
  const v2ext = process.platform === 'win32' ? '.dll' : process.platform === 'darwin' ? '.vst' : '.so';
  const r = { vst3: scanVst(d.vst3, '.vst3'), vst2: scanVst(d.vst2, v2ext) };
  // plugins dropped into the app's own plugin folder (AudioMixerPlugins) count once they pass the binary check
  try { for (const p of require('./plugins').scan().plugins) if (p.source === 'app' && p.valid && p.compatible) { const l = p.format === 'VST3' ? r.vst3 : r.vst2; if (!l.includes(p.name)) l.push(p.name); } } catch (_) { /* optional */ }
  return r;
}

// Optional: real host APIs / devices (ASIO, WASAPI, DirectSound, CoreAudio, ALSA) via PortAudio.
// Only used when `npm i naudiodon2` was run in bridge/ (needs a native build); otherwise skipped.
function detectPortAudio() {
  try {
    const pa = require('naudiodon2');
    const apis = pa.getHostAPIs().HostAPIs.map(h => h.name);
    const devices = pa.getDevices().map(d => ({ id: d.id, name: d.name, hostApi: d.hostAPIName, inputs: d.maxInputChannels, outputs: d.maxOutputChannels, sampleRate: d.defaultSampleRate }));
    return { engine: 'naudiodon', hostApis: apis, devices };
  } catch (_) { return null; }
}

// RtAudio's device probe is synchronous and loads every ASIO driver (hundreds of milliseconds, the whole event loop stands still, the audio sockets stutter). The page asks
// every few seconds; the probe result is reused for 15 s unless a rescan is asked for (?force=1) or this is the first one.
const audifyMemory = { at: 0, value: null };
// The operating-system scan (Windows: a PowerShell run plus registry reads, about a second of CPU and a large short-lived process) is the
// slowest and heaviest part of a scan, and drivers or registered ASIO entries do not change every few seconds: it is reused for 30 s.
// A rescan (?force=1: SCAN NOW, a device-change event) always runs it again. The result is copied, never shared, because callers add to it.
const osMemory = { at: 0, value: null, platform: null };
const OS_SCAN_MS = 30000;
async function osScan(force) {
  const p = process.platform, nowMs = Date.now();
  if (!force && osMemory.value && osMemory.platform === p && nowMs - osMemory.at < OS_SCAN_MS) return JSON.parse(JSON.stringify(osMemory.value));
  const v = p === 'win32' ? await windows() : p === 'darwin' ? await mac() : p === 'linux' ? await linux() : { drivers: [], devices: [], asio: [], recommended: null };
  Object.assign(osMemory, { at: Date.now(), value: JSON.parse(JSON.stringify(v)), platform: p });
  return v;
}
async function detect({ force = false } = {}) {
  if (force) nativeEngine.invalidate();   // the engine's device list is probed again too
  const p = process.platform;
  const r = await osScan(force);
  const naudiodon = detectPortAudio();
  const nowMs = Date.now();
  const audifyInfo = !force && audifyMemory.value && nowMs - audifyMemory.at < 15000 ? audifyMemory.value : detectAudify();
  if (audifyInfo !== audifyMemory.value) { audifyMemory.value = audifyInfo; audifyMemory.at = nowMs; }
  // `portaudio` is the primary native engine: naudiodon2 when installed, otherwise Audify (same shape, so the page works with either).
  const portaudio = naudiodon || audifyInfo;
  if (portaudio) {
    portaudio.devices.filter(d => /asio/i.test(d.hostApi) && !r.asio.includes(d.name)).forEach(d => r.asio.push(d.name));
    if (r.asio.length && Array.isArray(r.drivers) && !r.drivers.includes('steinberg')) r.drivers.push('steinberg');
  }
  // No audio engine installed: read the interfaces from the OS itself (Windows: C++ WASAPI helper, macOS: Core Audio, Linux: ALSA / Pulse)
  let native = portaudio ? null : p === 'win32' ? await winnative.listEndpoints() : await sysaudio.list();
  // last resort: the sound devices the OS reported (names only, direction unknown)
  if (!portaudio && !native && r.devices.length) native = { engine: 'os-devices', hostApis: [], devices: r.devices.map((d, i) => ({ id: -(i + 1), name: d.name, hostApi: p === 'win32' ? 'Windows' : p === 'darwin' ? 'Core Audio' : 'ALSA', native: true, listedOnly: true, inputs: 2, outputs: 2, sampleRate: 48000 })) };
  return { platform: p, arch: process.arch, node: process.version, ...r, vst: detectVst(), portaudio, audify: audifyInfo, native, engines: { naudiodon: !!naudiodon, audify: !!audifyInfo } };
}

module.exports = { detect, detectPortAudio, readAsioRegistry, parseAsioKeys };
