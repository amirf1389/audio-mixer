#!/usr/bin/env node
'use strict';
// Local audio sandbox bridge: zero dependencies, listens on loopback only.
//   GET /api/status   -> { ok, name, version }
//   GET /api/drivers  -> native driver/device detection for this OS
//   GET /api/volume   -> system output / input volume + mute
//   GET /api/license, GET /api/license/request (the key request file), POST /api/license/check (validity + upgrade report, stores nothing) | activate | deactivate -> consumer license (plan, machine code)
//   GET /api/update, POST /api/update/download, POST /api/update/install -> OTA updates (signed manifest, checksum-verified download, Windows-only silent install)
//   GET / POST /api/update/auto -> automatic updates for the Windows setup .exe (off by default; Android is updated by Google Play only)
//   GET /api/universal -> universal ASIO driver: all input / output sources, ranked, with the automatic pick
//   GET /api/plugins -> VST3 / VST2 plugins (.vst3 / .dll / .vst) found and validated
//   POST /api/handoff {scenes}, GET /api/handoff -> one scene archive (.amix) from "audio-mixer open" waiting for the page (taken once)
//   GET /api/power, POST /api/restart (X-Mixer-Action: restart) -> restart this server; POST /api/reboot (X-Mixer-Action: reboot, {confirm:'REBOOT'}) -> reboot the computer
//   GET /api/meters, POST /api/meters {clipDb} -> clip threshold (dBFS) of the level meters of native streams
//   WS  /ws/virtual, GET /api/virtual -> virtual audio devices of the operating-system drivers (drivers/); they appear in /api/interfaces and open like any interface
//   GET /api/audify, /api/framesize -> Audify (RtAudio) engine devices and automatic frame size
//   WS  /ws/output    -> page streams Int16 PCM out through PortAudio (ASIO / WASAPI)
//   GET /api/bluetooth, POST /api/bluetooth (X-Mixer-Action: bluetooth) -> paired / connected devices, airwaves scan, connect / pair / disconnect
//   GET /api/inserts, POST /api/inserts (X-Mixer-Action: inserts) -> plugin insert slots of the PHASE and FX pages
//   WS  /ws/insert    -> audio through a plugin of an insert slot (native plugin host, VST2 .dll / .vst)
//   WS  /ws/duplex    -> read AND write one interface through a single native stream
//   WS  /ws/input     -> bridge streams Int16 PCM captured from an ASIO / WASAPI input
//   GET /api/catalog  -> official audio drivers / stacks for this OS, with install detection
//   GET /api/nowplaying -> what Spotify / YouTube / YouTube Music / TIDAL / ... is playing (OS media sessions)
//   GET /api/interfaces -> every audio interface grouped across ASIO / WASAPI / DirectSound / Core Audio / ALSA ...
//   GET /api/sdks     -> third-party processing SDKs (AudioShake, GPU Audio, Camb.ai, Clarity Voice Studio): configured / wired state
//   GET /api/wasapi-exclusive -> experimental native WASAPI exclusive-mode addon (native/wasapi-exclusive): built / wired state (RtAudio itself is WASAPI shared-mode only)
//   GET /*            -> serves the mixer page from the repo root (same-origin use)
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { detect, detectPortAudio } = require('./detect');
const { accept } = require('./ws');
const { createSession } = require('./output');
const { createInputSession } = require('./input');
const { createDuplexSession } = require('./duplex');
const { readVolume } = require('./volume');
const { listCatalog } = require('./catalog');
const sdk = require('./sdk');
const wasapiExclusive = require('./wasapi-exclusive');
const levels = require('./levels');
const control = require('./control');
const licenseClient = require('./license-client');
const virtualHub = require('./virtual').hub;
const { cachedNowPlaying } = require('./nowplaying');
const { groupInterfaces } = require('./interfaces');
const audifyEngine = require('./audify');
const pluginScan = require('./plugins');
const universalDriver = require('./universal');
const bluetooth = require('./bluetooth');
let btCache = null;
const license = require('./license');
const updater = require('./update');
const streamRegistry = require('./streams');
const security = require('./security');
const diag = require('./diagnostics');
const inserts = require('./inserts');
const pluginHost = require('./pluginhost');
const power = require('./power');
const openSockets_ = new Set();

const VERSION = (() => { try { return require('../package.json').version; } catch (_) { return '1.0.0'; } })();
const autoUpdater = updater.createAutoUpdater({ current: VERSION, allowed: () => license.hasFeature(license.status(), 'ota'), log: m => console.log(m) });
const PORT = Number(process.env.BRIDGE_PORT) || 8765;
const HOST = '127.0.0.1';
const ROOT = path.resolve(__dirname, '..');
const EXTRA_ORIGINS = (process.env.BRIDGE_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
const EXTRA_HOSTS = (process.env.BRIDGE_HOSTS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
const ALLOW_NULL_ORIGIN = process.env.BRIDGE_ALLOW_NULL_ORIGIN !== '0'; // file:// pages send "null"; set 0 to refuse even reads
// Origin "null" is ALSO what any website's sandboxed iframe sends, so by default it may only READ (GET); actions, preflights and the audio
// WebSockets (microphone / interface audio) need a real local origin. BRIDGE_ALLOW_NULL_ORIGIN=1 restores full access for file:// development.
const NULL_ORIGIN_FULL = process.env.BRIDGE_ALLOW_NULL_ORIGIN === '1';
const isLocalOrigin = o => { try { const h = new URL(o).hostname; return h === 'localhost' || h === '127.0.0.1' || h === '[::1]'; } catch (_) { return false; } };
const SECURITY_HEADERS = security.HEADERS;
const RATE = process.env.BRIDGE_RATE_LIMIT === '0' ? 0 : 1;   // 0 turns the request limits off
const limiter = security.createLimiter();
const MAX_SOCKETS = 24;                                         // open audio WebSockets at the same time
let openSockets = 0;
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };

// Only local pages (and file:// pages, which send "null") may read the API.
function originAllowed(o) {
  if (!o) return true;
  if (o === 'null') return ALLOW_NULL_ORIGIN;
  if (EXTRA_ORIGINS.includes(o)) return true;
  try { const h = new URL(o).hostname; return h === 'localhost' || h === '127.0.0.1' || h === '[::1]'; } catch (_) { return false; }
}

// DNS-rebinding guard: the Host header must name this machine's loopback, whatever the Origin says.
function hostAllowed(h) {
  if (!h) return false;
  const name = String(h).toLowerCase().replace(/:\d+$/, '');
  return name === 'localhost' || name === '127.0.0.1' || name === '[::1]' || EXTRA_HOSTS.includes(name);
}

function send(res, code, body, headers = {}) {
  res.writeHead(code, { 'Cache-Control': 'no-store', ...SECURITY_HEADERS, ...headers });
  res.end(body);
}
const json = (res, code, obj, h) => send(res, code, JSON.stringify(obj), { 'Content-Type': 'application/json', ...h });

const server = http.createServer(async (req, res) => {
  try { await handle(req, res); }
  catch (_) { if (!res.headersSent) json(res, 500, { ok: false, error: 'internal error' }); else res.destroy(); }
});

async function handle(req, res) {
  const origin = req.headers.origin;
  if (!hostAllowed(req.headers.host)) return json(res, 403, { ok: false, error: 'host not allowed' });
  if (!originAllowed(origin)) return json(res, 403, { ok: false, error: 'origin not allowed' });
  if (origin === 'null' && !NULL_ORIGIN_FULL && req.method !== 'GET' && req.method !== 'HEAD') return json(res, 403, { ok: false, error: 'actions need the app page (http://localhost), not an opaque origin' });
  if (RATE && req.url.startsWith('/api/')) {   // per page origin: reads 900/min, actions (POST) 40/min
    const post = req.method === 'POST', r = limiter.allow((post ? 'p:' : 'g:') + (origin || 'local'), post ? 40 : 900);
    if (!r.ok) return json(res, 429, { ok: false, error: 'too many requests, retry in ' + r.retryAfter + ' s' }, { 'Retry-After': String(r.retryAfter) });
  }
  const cors = origin ? { 'Access-Control-Allow-Origin': origin, 'Vary': 'Origin', ...(isLocalOrigin(origin) || EXTRA_ORIGINS.includes(origin) ? { 'Access-Control-Allow-Private-Network': 'true' } : {}) } : {};   // never invite public pages into the private network
  if (req.method === 'OPTIONS') return send(res, 204, '', { ...cors, 'Access-Control-Allow-Methods': 'GET, POST', 'Access-Control-Allow-Headers': 'Content-Type, X-Mixer-Action' });
  const url = new URL(req.url, `http://${HOST}`);
  if (req.method === 'POST' && url.pathname === '/api/license/activate') return handleAction(req, res, cors, 'license', async body => {
    const key = String(body.key || '').trim().replace(/\s+/g, '');
    const remote = await licenseClient.activate(key, license.machineId());     // the 4-computer device lock (when LICENSE_SERVER_URL is set)
    if (remote.ok === false) return [remote.status === 409 ? 409 : 400, { ok: false, reason: 'device-limit', error: remote.message }];
    const stored = license.readStored();
    if (remote.offline && !(stored && stored.key === key)) return [503, { ok: false, error: 'Could not reach the license server to check how many computers use this key. Connect to the internet and try again.' }];
    const r = license.activate(body.key);
    return r.ok ? [200, r] : [400, r];
  });
  if (req.method === 'POST' && url.pathname === '/api/license/check') return handleAction(req, res, cors, 'license', async body => [200, license.check(String(body.key || '').trim().replace(/\s+/g, ''))]);   // read-only: nothing stored, no device registered
  if (req.method === 'POST' && url.pathname === '/api/license/deactivate') return handleAction(req, res, cors, 'license', async () => {
    const stored = license.readStored();
    if (stored && stored.key) await licenseClient.deactivate(stored.key, license.machineId());
    return [200, license.deactivate()];
  }, false);
  if (req.method === 'POST' && url.pathname === '/api/update/download') return handleAction(req, res, cors, 'update', async () => {
    if (!license.hasFeature(license.status(), 'ota')) return [402, { ok: false, needs: 'ota', error: 'Downloading updates needs the PRO or STUDIO plan. You can still check for updates.' }];
    return [200, await updater.download({ current: VERSION })];
  }, false);
  if (req.method === 'POST' && url.pathname === '/api/update/install') return handleAction(req, res, cors, 'update', async () => {
    if (!license.hasFeature(license.status(), 'ota')) return [402, { ok: false, needs: 'ota', error: 'Installing updates needs the PRO or STUDIO plan. You can still check for updates.' }];
    return [200, await updater.install({ current: VERSION })];
  }, false);
  if (req.method === 'POST' && url.pathname === '/api/update/auto') return handleAction(req, res, cors, 'update', async body => {
    if (typeof body.enabled !== 'boolean') return [400, { ok: false, error: 'enabled must be true or false' }];
    if (body.enabled && !license.hasFeature(license.status(), 'ota')) return [402, { ok: false, needs: 'ota', error: 'Automatic updates need the PRO or STUDIO plan.' }];
    updater.setAutoEnabled(body.enabled);
    if (body.enabled) autoUpdater.tick();                                   // check right away; the result shows in GET /api/update/auto
    return [200, { ok: true, ...autoUpdater.status() }];
  });
  if (req.method === 'POST' && url.pathname === '/api/handoff') return handleAction(req, res, cors, 'handoff', async body => {   // "audio-mixer open file.amix": one scene archive waits here for the page
    const d = body && body.scenes;
    if (!Array.isArray(d) || d.length > 16 || !d.every(x => x === null || (x && typeof x === 'object' && !Array.isArray(x)))) return [400, { ok: false, error: 'scenes must be an array of up to 16 snapshots' }];
    handoff = { scenes: d, at: Date.now() };
    return [200, { ok: true, snapshots: d.filter(Boolean).length }];
  }, true, 1 << 20);
  if (req.method === 'POST' && url.pathname === '/api/select-device') return handleAction(req, res, cors, 'select-device', async body => {   // the ASIO driver new output streams open
    const info = await detectCached(true), name = control.select(body.deviceName, info.asio);
    return [200, { ok: true, selected: name, message: `Output streams now open ${name}` }];
  });
  if (req.method === 'POST' && url.pathname === '/api/restart') return handleAction(req, res, cors, 'restart', async () => [200, { ok: true, restarting: true, ...power.restartSelf({ server, sockets: openSockets_ }) }], false);
  if (req.method === 'POST' && url.pathname === '/api/reboot') return handleAction(req, res, cors, 'reboot', async body => {     // the computer itself: only with the word REBOOT in the request
    if (body.cancel === true) return [200, await power.rebootOs({ cancel: true })];
    if (body.confirm !== 'REBOOT') return [400, { ok: false, error: 'send {"confirm":"REBOOT"} to reboot the computer' }];
    return [200, await power.rebootOs()];
  });
  if (req.method === 'POST' && url.pathname === '/api/meters') return handleAction(req, res, cors, 'meters', async body => [200, { ok: true, clipDb: levels.setClipDb(body.clipDb) }]);
  if (req.method === 'POST' && url.pathname === '/api/bluetooth') return handleAction(req, res, cors, 'bluetooth', async body => {
    try {
      if (body.action === 'scan') { btCache = null; return [200, await bluetooth.scan({ seconds: body.seconds })]; }
      if (body.action === 'settings') return [200, bluetooth.openSettings()];
      btCache = null; return [200, await bluetooth.act(String(body.action || ''), body.address)];
    } catch (e) { return [e.status || 500, { ok: false, error: e.message }]; }
  });
  if (req.method === 'POST' && url.pathname === '/api/inserts') return handleAction(req, res, cors, 'inserts', async body => {
    if (body.clear === true) { inserts.write({ slots: {} }); return [200, { ok: true, slots: {} }]; }      // factory reset: every slot empty, on any plan
    if (!license.hasFeature(license.status(), 'plugins')) return [402, { ok: false, error: 'Plugin inserts need the PRO or STUDIO plan', needs: 'plugins' }];
    return [200, { ok: true, ...inserts.set(body) }];
  });
  // SIMULATED DEVICES (bridge/sim): POST {enabled, profiles, faults} with X-Mixer-Action: sim (local page only, like every action)
  if (req.method === 'POST' && url.pathname === '/api/sim') return handleAction(req, res, cors, 'sim', async body => {
    const sim = require('./sim');
    const st = sim.configure({ enabled: body.enabled, profiles: body.profiles, faults: body.faults });
    if (body.enabled === false) sim.closeAll();
    detectCache = null; lastScanSig = '';
    diag.info('sim', `simulated devices ${st.enabled ? 'ON: ' + st.profiles.join(', ') + (Object.keys(st.faults).length ? ' (faults: ' + JSON.stringify(st.faults) + ')' : '') : 'OFF'}`);
    return [200, { ok: true, ...st }];
  });
  if (req.method !== 'GET') return json(res, 405, { ok: false, error: 'method not allowed' }, cors);
  if (url.pathname === '/api/handoff') {   // the page takes the waiting scene archive once (it is dropped after 2 minutes)
    const h = handoff && Date.now() - handoff.at < 120000 ? handoff : null; handoff = null;
    return json(res, 200, h ? { ok: true, scenes: h.scenes } : { ok: false }, cors);
  }
  if (url.pathname === '/api/status') return json(res, 200, { ok: true, name: 'audio-mixer-bridge', version: VERSION, node: process.version, pid: process.pid, uptimeSec: Math.round(process.uptime()), streams: streamRegistry.list(), time: Date.now() }, cors);
  // Consumer licensing: the plan this copy runs as, this computer's machine code, and the stored key's state
  if (url.pathname === '/api/bluetooth') {   // paired / connected devices of this computer (shared for 2 s: the page polls)
    if (!btCache || Date.now() - btCache.at > 2000 || url.searchParams.get('force') === '1') btCache = { at: Date.now(), promise: bluetooth.list() };
    return json(res, 200, await btCache.promise, cors);
  }
  if (url.pathname === '/api/inserts') return json(res, 200, { ok: true, host: { available: !!pluginHost.hostPath(), formats: ['VST2', 'VST3'] }, ...inserts.read() }, cors);
  if (url.pathname === '/api/virtual') return json(res, 200, { ok: true, devices: virtualHub.list() }, cors);
  // Third-party processing SDKs (AudioShake, GPU Audio, Camb.ai, Clarity Voice Studio): which are configured (API key set) and wired (a real client installed) - see bridge/sdk.js.
  if (url.pathname === '/api/sdks') return json(res, 200, { ok: true, providers: sdk.status() }, cors);
  // WASAPI exclusive mode: RtAudio (bridge/audify.js) has no exclusive-mode path at all; this reports whether the experimental native/wasapi-exclusive addon is built here (it stays unwired - see its README.md).
  if (url.pathname === '/api/wasapi-exclusive') return json(res, 200, { ok: true, ...wasapiExclusive.status() }, cors);
  if (url.pathname === '/api/power') return json(res, 200, { ok: true, pid: process.pid, ...power.capabilities() }, cors);
  if (url.pathname === '/api/meters') return json(res, 200, { ok: true, clipDb: levels.config.clipDb, clipRun: levels.CLIP_RUN }, cors);   // clip threshold of the native streams' meters
  if (url.pathname === '/api/license/request') {            // the request file for a key (machine code, plan, name): GET /api/license/request?plan=pro&name=Jane&email=jane@example.com
    try { return json(res, 200, { ok: true, request: license.request({ plan: url.searchParams.get('plan') || 'pro', name: url.searchParams.get('name'), email: url.searchParams.get('email') }) }, cors); }
    catch (e) { return json(res, e.status || 500, { ok: false, error: e.message }, cors); }
  }
  if (url.pathname === '/api/update/auto') return json(res, 200, { ok: true, ...autoUpdater.status() }, cors);
  if (url.pathname === '/api/license') return json(res, 200, { ok: true, version: VERSION, ...license.status(), sandboxKey: license.sandboxJwk() }, cors);

  // OTA updates: is a newer, signed version published? (cached for 5 minutes, ?force=1 asks again)
  if (url.pathname === '/api/update') {
    try {
      const force = url.searchParams.get('force') === '1';
      if (force || !updateCache || Date.now() - updateCache.at > 300000) updateCache = { at: Date.now(), data: await updater.check({ current: VERSION }) };
      return json(res, 200, updateCache.data, cors);
    } catch (e) { return json(res, e.status || 502, { ok: false, current: VERSION, error: e.message }, cors); }
  }

  // AUDIO DIAGNOSTICS (bridge/diagnostics.js): GET /api/diagnostics?filter=all|errors|asio|wasapi&since=<seq>, GET /api/diagnostics/report (plain text)
  if (url.pathname === '/api/diagnostics') return json(res, 200, { ok: true, logFile: diag.fileFor().replace(/([A-Za-z]:\\Users\\|\/(?:home|Users)\/)[^\\/]+/, '$1<user>'), entries: diag.list({ filter: url.searchParams.get('filter') || 'all', since: parseInt(url.searchParams.get('since'), 10) || 0 }), sim: require('./sim').status() }, cors);
  if (url.pathname === '/api/diagnostics/report') return send(res, 200, diag.report({ version: VERSION }), { ...cors, 'Content-Type': 'text/plain; charset=utf-8', 'Content-Disposition': 'attachment; filename="amfx1-audio-diagnostics.txt"' });
  // SIMULATED DEVICES (bridge/sim): GET status; POST {enabled, profiles, faults} with X-Mixer-Action: sim (local page only, like every action)
  if (url.pathname === '/api/sim') return json(res, 200, { ok: true, ...require('./sim').status() }, cors);
  if (url.pathname === '/api/drivers') {
    try { return json(res, 200, { ok: true, ...(await detectCached(url.searchParams.get('force') === '1')) }, cors); }
    catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  if (url.pathname === '/api/audio-devices') {            // the ASIO drivers on this PC and the one chosen with POST /api/select-device
    try { const info = await detectCached(url.searchParams.get('force') === '1'); return json(res, 200, { ok: true, devices: info.asio || [], selected: control.selected() }, cors); }
    catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  if (url.pathname === '/api/nowplaying') {
    try { return json(res, 200, { ok: true, ...(await cachedNowPlaying()) }, cors); }
    catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  if (url.pathname === '/api/interfaces') {
    try {
      const info = await detectCached(url.searchParams.get('force') === '1');
      const src = url.searchParams.get('engine') === 'audify' && info.audify ? info.audify : info.portaudio;
      const devices = src ? src.devices : (info.native ? info.native.devices : []);
      return json(res, 200, { ok: true, platform: info.platform, portaudio: !!info.portaudio || virtualHub.list().length > 0, engine: src ? src.engine : (info.native ? info.native.engine : null), asio: info.asio, interfaces: groupInterfaces(devices.concat(virtualHub.list().map(v => ({ id: v.id, name: v.name, hostApi: 'Audio Mixer Virtual', inputs: v.channels, outputs: v.channels, sampleRate: v.rate }))), info.asio, src && src.problems) }, cors);
    } catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  // Audify (RtAudio) engine: every compiled host API with its devices and the automatic frame size for each.
  if (url.pathname === '/api/audify') {
    try { return json(res, 200, { ok: true, ...audifyEngine.describe() }, cors); }
    catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  // Universal ASIO driver: every input and output source on this PC (PortAudio + Audify, all host APIs), best first, with the automatic pick
  if (url.pathname === '/api/universal') {
    try {
      const pa = detectPortAudio(), au = audifyEngine.detectAudify();
      const lists = [];
      if (pa) lists.push({ engine: 'naudiodon', devices: pa.devices });
      if (au) lists.push({ engine: 'audify', devices: au.devices });
      return json(res, 200, { ok: true, engines: { naudiodon: !!pa, audify: !!au }, ...universalDriver.detectSources(lists), time: Date.now() }, cors);
    } catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  // Plugin system: VST3 / VST2 (.vst3, .dll, .vst) in the standard folders and the app's own plugin folder, each binary checked.
  if (url.pathname === '/api/plugins') {
    try { return json(res, 200, { ok: true, ...pluginScan.scan({ hash: url.searchParams.get('hash') === '1' }) }, cors); }
    catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  // Automatic ASIO / host-API buffer size: /api/framesize?api=ASIO&sampleRate=48000&channels=2[&latency=ms]
  if (url.pathname === '/api/framesize') {
    const q = url.searchParams, num = (k, d) => (q.has(k) ? Number(q.get(k)) : d);
    const sampleRate = num('sampleRate', 48000), channels = num('channels', 2), latencyMs = q.has('latency') ? Number(q.get('latency')) : undefined;
    if (!(sampleRate >= 8000 && sampleRate <= 384000) || !(Number.isInteger(channels) && channels >= 1 && channels <= 128) || (latencyMs !== undefined && !(latencyMs > 0 && latencyMs <= 1000))) {
      return json(res, 400, { ok: false, error: 'sampleRate (8000-384000), channels (1-128) or latency (ms) out of range' }, cors);
    }
    const api = q.get('api') || 'ASIO';
    if (!audifyEngine.apiKey(api)) return json(res, 400, { ok: false, error: 'unknown api: use ASIO, WASAPI, DirectSound, CoreAudio, JACK, ALSA, Pulse or OSS' }, cors);
    const p = audifyEngine.plan('auto', { api, sampleRate, channels, latencyMs });
    return json(res, 200, { ok: true, ...p.recommended, candidates: p.candidates, min: audifyEngine.MIN_FRAMES, max: audifyEngine.MAX_FRAMES }, cors);
  }

  if (url.pathname === '/api/catalog') {
    try {
      const info = await detect();
      return json(res, 200, { ok: true, platform: info.platform, items: listCatalog(info) }, cors);
    } catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  if (url.pathname === '/api/volume') {
    try { return json(res, 200, { ok: true, ...(await readVolume()) }, cors); }
    catch (e) { return json(res, 500, { ok: false, error: e.message }, cors); }
  }

  // Static page (path-traversal safe)
  let rel;
  try { rel = decodeURIComponent(url.pathname); } catch (_) { return json(res, 400, { ok: false, error: 'bad request' }); }
  if (rel.includes('\0')) return json(res, 400, { ok: false, error: 'bad request' });
  if (rel === '/') rel = '/index.html';
  const embedded = global.__AM_ASSETS && Object.prototype.hasOwnProperty.call(global.__AM_ASSETS, rel) ? global.__AM_ASSETS[rel] : null;   // the single-file build (scripts/build-single.js) carries the page inside
  if (embedded) return send(res, 200, embedded, { 'Content-Type': TYPES[path.extname(rel).toLowerCase()] || 'application/octet-stream' });
  const file = path.resolve(ROOT, '.' + rel);
  if (file !== ROOT && !file.startsWith(ROOT + path.sep)) return json(res, 403, { ok: false, error: 'forbidden' });
  // Never serve dotfiles/dirs (.git, .github, .vscode, .env ...) or the bridge's own sources.
  if (path.relative(ROOT, file).split(path.sep).some(p => p.startsWith('.')) || file.startsWith(__dirname + path.sep) || !security.staticAllowed(ROOT, file)) return json(res, 404, { ok: false, error: 'not found' });
  fs.readFile(file, (err, buf) => {
    if (err) return json(res, 404, { ok: false, error: 'not found' });
    const type = TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream';
    send(res, 200, buf, { 'Content-Type': type });
  });
}

// Device detection runs PowerShell / reg / RtAudio probes: the page rescans every few seconds and several pages ask, so concurrent and repeated requests
// share one run for a few seconds (?force=1 bypasses it). A failed run is not kept.
let detectCache = null;
function detectCached(force = false, maxAgeMs = 3000) {
  const now = Date.now();
  if (!force && detectCache && now - detectCache.at < maxAgeMs) return detectCache.promise;
  const promise = detect({ force }); detectCache = { at: now, promise };
  promise.then(logScan, () => {});
  promise.catch(() => { if (detectCache && detectCache.promise === promise) detectCache = null; });
  return promise;
}

// the device scan in the diagnostics log: once per change of the device list (not every 3 s poll), per host API
let lastScanSig = '';
function logScan(info) {
  try {
    const src = info.portaudio || info.native || { devices: [] }, devs = src.devices || [];
    const by = {}; for (const d of devs) (by[d.hostApi || 'other'] = by[d.hostApi || 'other'] || []).push(`${d.name} (${d.inputs || 0} in / ${d.outputs || 0} out${d.probeFailed ? ', probe failed' : ''})`);
    const sig = JSON.stringify([src.engine, by, info.asio]);
    if (sig === lastScanSig) return; lastScanSig = sig;
    diag.info('scan', `device scan (${src.engine || 'no engine'}${src.simulated ? ', SIMULATED DEVICES' : ''}): ${devs.length} device(s); ASIO drivers installed: ${(info.asio || []).join(', ') || 'none'}`);
    for (const [api, list] of Object.entries(by)) diag.info(/asio/i.test(api) ? 'asio' : /wasapi/i.test(api) ? 'wasapi' : 'scan', `${api}: ${list.join('; ')}`);
    if (!info.portaudio) diag.warn('scan', 'no audio engine (PortAudio / Audify) is installed: devices are listed from the operating system and cannot be opened by the bridge');
  } catch (_) { /* logging never breaks a scan */ }
}

let updateCache = null;
let handoff = null;
// JSON POST actions (license, updates): the custom header forces a CORS preflight, so foreign pages cannot trigger them.
async function handleAction(req, res, cors, action, fn, wantBody = true, maxBody = 8192) {
  if (req.headers['x-mixer-action'] !== action) return json(res, 400, { ok: false, error: 'missing X-Mixer-Action: ' + action }, cors);
  let body = {};
  if (wantBody) {
    if (!String(req.headers['content-type'] || '').startsWith('application/json')) return json(res, 400, { ok: false, error: 'JSON body required' }, cors);
    let raw = '';
    for await (const chunk of req) { raw += chunk; if (raw.length > maxBody) return json(res, 413, { ok: false, error: 'request too large' }, cors); }
    try { body = JSON.parse(raw || '{}'); } catch (_) { return json(res, 400, { ok: false, error: 'invalid JSON' }, cors); }
  } else { for await (const _ of req) { /* drain */ } }
  try { const [code, data] = await fn(body); return json(res, code, data, cors); }
  catch (e) { return json(res, e.status || 500, { ok: false, error: e.message }, cors); }
}

// WebSocket /ws/output: page streams Int16 PCM, bridge plays it via PortAudio (ASIO when available).
server.on('upgrade', (req, socket) => {
  let pathname = '';
  try { pathname = new URL(req.url, `http://${HOST}`).pathname; } catch (_) { /* rejected below */ }
  if ((pathname !== '/ws/output' && pathname !== '/ws/input' && pathname !== '/ws/duplex' && pathname !== '/ws/insert' && pathname !== '/ws/virtual' && pathname !== '/ws/control') || !hostAllowed(req.headers.host) || !originAllowed(req.headers.origin) || (req.headers.origin === 'null' && !NULL_ORIGIN_FULL)) { socket.destroy(); return; }   // audio sockets: never from an opaque (sandboxed) origin
  if (pathname === '/ws/virtual' && req.headers.origin) { socket.destroy(); return; }     // drivers are native programs: a web page has no business here
  if (openSockets >= MAX_SOCKETS || (RATE && !limiter.allow('ws', 120).ok)) { socket.end('HTTP/1.1 429 Too Many Requests\r\nConnection: close\r\n\r\n'); return; }
  const handlers = {};
  const conn = accept(req, socket, handlers);
  if (!conn) return;
  openSockets++; socket.once('close', () => { openSockets--; });
  Object.assign(handlers, pathname === '/ws/input' ? createInputSession(conn) : pathname === '/ws/duplex' ? createDuplexSession(conn) : pathname === '/ws/insert' ? pluginHost.createInsertSession(conn) : pathname === '/ws/virtual' ? virtualHub.session(conn) : pathname === '/ws/control' ? control.session(conn) : createSession(conn));
});

server.on('connection', s => { openSockets_.add(s); s.once('close', () => openSockets_.delete(s)); });
server.headersTimeout = 15000; server.requestTimeout = 60000; server.maxHeadersCount = 64; server.keepAliveTimeout = 5000;
server.on('clientError', (_, socket) => { try { socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); } catch (_) { /* gone */ } });

// Starts listening (used by the client launcher); resolves with the port.
function start(port = PORT) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, HOST, () => { server.removeListener('error', reject); autoUpdater.start(); try { license.status(); } catch (_) { /* a paid edition activates here on first start; Basic: nothing to do */ } resolve(server.address().port); });
  });
}

if (require.main === module) {
  start().then(port => {
    console.log(`Audio Mixer bridge running: http://localhost:${port}  (open this URL to use the mixer)`);
    // Which host APIs this server's audio binary was built with (RtAudio.getCompiledApi), logged once at startup so a missing ASIO / WASAPI backend is visible in the console.
    try {
      const mod = audifyEngine.loadAudify(); const list = typeof mod.RtAudio.getCompiledApi === 'function' ? mod.RtAudio.getCompiledApi() : [];
      console.log(`Audio engine compiled APIs: ${(list || []).map(String).join(', ') || '(none reported)'}`);
    } catch (e) { console.log(`Audio engine (audify) not available: ${String(e && e.message || e).split('\n')[0]}`); }
    // ASIO is always checked at startup, through the Steinberg SDK (the native engine's --probe-asio), not RtAudio. It runs in the background: startup does not wait for it.
    const asioProbe = require('./asio-probe');
    // The native engine sits in the install root, next to bridge/ (not on PATH): give the probe that exact file.
    asioProbe.probeAsio({ exe: path.join(__dirname, '..', 'audiomixer-native.exe') }).then(r => asioProbe.describeAsio(r).forEach(line => console.log(line))).catch(e => console.log(`ASIO: not checked (${String(e && e.message || e).split('\n')[0]})`));
  });
}
module.exports = { detectCached, server, originAllowed, hostAllowed, HOST, PORT, start };
