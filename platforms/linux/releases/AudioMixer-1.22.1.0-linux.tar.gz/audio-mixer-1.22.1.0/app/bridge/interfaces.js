'use strict';
// Groups the PortAudio devices of every host API (ASIO, WASAPI, DirectSound, WDM-KS, MME, Core Audio, ALSA, JACK ...)
// into physical audio interfaces, so each interface shows once with all the ways it can be opened.
const API_RANK = [/asio/i, /wasapi/i, /core ?audio/i, /jack/i, /alsa/i, /wdm|kernel/i, /direct ?sound/i, /mme/i];
const apiRank = a => { const i = API_RANK.findIndex(r => r.test(a || '')); return i < 0 ? API_RANK.length : i; };
const LOOPBACK = /stereo mix|what u hear|wave out mix|monitor of|loopback|virtual cable|cable output|blackhole|soundflower|voicemeeter out/i;

// DirectSound's "Primary Sound Capture Driver" / "Primary Sound Driver" are Windows' default-device mappers, not hardware: they duplicate
// the real default device and often fail to open. They are listed last as the system default and never enabled automatically.
const PRIMARY = /^primary sound (capture )?driver$/i;
const isPrimary = n => PRIMARY.test(String(n || '').trim());

// Bluetooth headsets show up as TWO Windows devices: "Headphones (X Stereo)" (A2DP, stereo output) and "Headset (X Hands-Free AG Audio)"
// (HFP, mono 8 / 16 kHz microphone + speaker). They are one physical device: group them, write through A2DP, read through the HFP microphone.
const HFP = /hands[- ]?free|\bhfp\b|\bag audio\b/i;
const BT_HINT = /bluetooth|\ba2dp\b|\bbluez/i;
const btBase = (n, keepCase) => {
  const m = /\(([^()]+)\)\s*$/.exec(String(n || '').trim());
  const b = (m ? m[1] : String(n || '')).replace(/\s*(hands[- ]?free(\s+ag(\s+audio)?)?|ag audio|hfp|a2dp|stereo|bluetooth)\s*$/i, '').trim();
  return keepCase ? b : b.toLowerCase();
};
const isBluetooth = n => HFP.test(n || '') || BT_HINT.test(n || '');
const btProfile = n => (HFP.test(n || '') ? 'hfp' : 'a2dp');

// "Microphone (Focusrite USB Audio)" -> "Focusrite USB Audio"; "Focusrite USB ASIO" -> key "focusrite"
function baseName(n) {
  const m = /^(?:microphone|speakers|headphones|headset|line in|line out|line|input|output|digital audio(?: \(s\/pdif\))?|stereo mix|analog|aux)\s*\((.+)\)\s*$/i.exec(String(n || '').trim());
  return (m ? m[1] : String(n || '')).trim();
}
function keyOf(n) {
  const k = baseName(n).toLowerCase().replace(/\b(asio|wasapi|audio|driver|usb|input|output|microphone|speakers?|headphones?|line|in|out|device|class|compliant|\d+-?\d*)\b/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim();
  return k || baseName(n).toLowerCase();
}

// MME and DirectSound cut device names at 31 characters ("Microphone (Focusrite USB Audi"), so the same interface listed by WASAPI under its full
// name ("Microphone (Focusrite USB Audio)") showed up a second time. A cut name is read as the longer name it is the start of.
const CUT = 28;
function untruncate(devices) {
  const names = [...new Set(devices.map(d => String(d.name || '')))];
  return devices.map(d => {
    const n = String(d.name || '');
    if (n.length < CUT || /\)\s*$/.test(n)) return d;
    const full = names.filter(m => m.length > n.length && m.toLowerCase().startsWith(n.toLowerCase())).sort((a, b) => a.length - b.length)[0];
    return full ? { ...d, name: full } : d;
  });
}

// An engine device (id >= 0) that could not be probed has no channels; the operating system's endpoint list knows the same device by name together with
// its direction and channel count: take the mode from there, so READ / WRITE are offered instead of "no input, no output".
function inferProbeFailed(devices) {
  return devices.map(d => {
    if (!d.probeFailed || d.inputs || d.outputs) return d;
    const n = String(d.name || '').toLowerCase();
    const e = devices.find(x => x !== d && !x.probeFailed && (x.inputs || x.outputs) && String(x.name || '').toLowerCase() === n);
    return e ? { ...d, inputs: e.inputs, outputs: e.outputs, inferred: true } : d;
  });
}

// Why an installed ASIO driver (registry) is not in the engine's list: the probe error RtAudio gave (RtApiAsio::probeDeviceInfo ...), when it named this driver
// or failed as a whole; nothing when the engine simply does not list it (driver without a device, engine without ASIO).
function probeReason(name, problems) {
  const k = keyOf(name);
  for (const p of problems || []) {
    if (!p || !/asio/i.test(p.api || '')) continue;
    const named = (p.unprobed || []).some(u => keyOf(u) === k) || (p.kept || []).some(u => keyOf(u) === k);
    if (named || p.message) return { probeError: String(p.message || 'the driver answered with no channels').slice(0, 200), probeNamed: named, probeRetried: !!p.retried };
  }
  return {};
}

function groupInterfaces(devices = [], asioNames = [], problems = []) {
  devices = inferProbeFailed(untruncate(devices));
  const groups = new Map();
  const hfpBases = new Set(devices.filter(d => HFP.test(d.name || '')).map(d => btBase(d.name)));
  for (const d of devices) {
    const isStereoBt = !HFP.test(d.name || '') && !LOOPBACK.test(d.name || '') && /\bstereo\)\s*$/i.test(d.name || '') && hfpBases.has(btBase(d.name));
    const bt = HFP.test(d.name || '') || BT_HINT.test(d.name || '') || isStereoBt;
    const key = bt && btBase(d.name) ? 'bt:' + btBase(d.name) : keyOf(d.name) + (LOOPBACK.test(d.name) ? ':loopback' : '');   // a loopback device is never merged into a real interface
    const g = groups.get(key) || { key, names: [], apis: [], inputs: 0, outputs: 0, loopback: false, systemDefault: false };
    if (isPrimary(d.name)) g.systemDefault = true;
    g.names.push(baseName(d.name));
    if (bt) g.bluetooth = true;
    g.apis.push({ api: d.hostApi || d.hostAPIName || 'default', deviceId: d.id, ...(bt ? { profile: btProfile(d.name) } : {}), inputs: d.inputs || 0, outputs: d.outputs || 0, sampleRate: d.sampleRate || null });
    g.inputs = Math.max(g.inputs, d.inputs || 0); g.outputs = Math.max(g.outputs, d.outputs || 0);
    if (LOOPBACK.test(d.name)) g.loopback = true;
    groups.set(key, g);
  }
  const out = [];
  for (const g of groups.values()) {
    // same host API: the A2DP stereo endpoint before the hands-free one (opening hands-free drops the headset to phone quality)
    g.apis.sort((a, b) => (apiRank(a.api) - apiRank(b.api)) || ((a.profile === 'hfp') - (b.profile === 'hfp')));
    const read = g.apis.find(a => a.inputs > 0) || null, write = g.apis.find(a => a.outputs > 0) || null;
    const asioDev = g.apis.find(a => /asio/i.test(a.api));
    const name0 = (asioDev ? g.names[g.apis.indexOf(asioDev)] : g.names.slice().sort((a, b) => b.length - a.length)[0]) || g.key;
    const name = g.bluetooth ? btBase(g.names[0], true) || name0 : name0;
    out.push({ key: g.key, name: g.systemDefault ? 'System default ' + (g.inputs ? 'input' : 'output') + ' (' + name + ')' : name, inputs: g.inputs, outputs: g.outputs, loopback: g.loopback, asio: !!asioDev, systemDefault: g.systemDefault, bluetooth: !!g.bluetooth, apis: g.apis, read, write });
  }
  // Installed ASIO drivers that PortAudio does not list (not installed yet, device unplugged, or PortAudio missing).
  for (const n of asioNames) {
    const k = keyOf(n);
    if (!groups.has(k)) out.push({ key: k, name: baseName(n), inputs: 0, outputs: 0, loopback: false, asio: true, apis: [], read: null, write: null, driverOnly: true, ...probeReason(n, problems) });
  }
  linkAsioFallback(out);
  // ASIO4ALL / FlexASIO wrap Windows devices that may also be open through their own driver: flagged, and never enabled automatically when a
  // device with its own ASIO driver is present
  const nativeAsio = out.some(g => g.asio && !hw.isWrapper(g.name) && !g.driverOnly);
  for (const g of out) if (g.asio && hw.isWrapper(g.name)) { g.wrapper = true; if (nativeAsio) g.preferNative = true; }
  // The Windows endpoints of hardware that also has its own ASIO driver ("USB Audio CODEC" next to "BEHRINGER USB AUDIO"): reading both opens the
  // SAME microphone twice (a doubled, comb-filtered voice). The twin is marked for the directions the ASIO driver already covers; the page
  // does not enable those automatically. It stays usable by hand and is what the ASIO -> Windows fallback opens.
  for (const g of out) {
    if (g.asio || g.loopback || g.bluetooth || g.systemDefault) continue;
    let best = null, sc = 0;
    for (const a of out) { if (!a.asio || a.wrapper || a.driverOnly) continue; const v = hw.score(a.name, g.name); if (v > sc) { sc = v; best = a; } }
    if (best && sc >= 100) g.twinOf = { key: best.key, name: best.name, read: best.inputs > 0 && !(best.fallback && best.fallback.input), write: best.outputs > 0 && !(best.fallback && best.fallback.output) };
  }
  return out.sort((a, b) => (a.systemDefault - b.systemDefault) || (a.loopback - b.loopback) || (b.asio - a.asio) || a.name.localeCompare(b.name));
}

// An ASIO interface with no input or no output (Realtek ASIO often shows outputs only, or none; a probe can fail while another program holds
// the driver) gets the missing side from the Windows endpoint of the same hardware, so the page can still read / write it. The same match the
// engine uses for its runtime fallback (native-engine.wasapiFallback): chip family first, then name words, never a loopback or Bluetooth device.
const hw = require('./hw-match');   // chip / product families shared with the engine fallback, the silence fallback and the simulator
const familyOf = hw.family;
const wordsOf = hw.words;
function linkAsioFallback(list) {
  for (const a of list) {
    if (!a.asio || (a.read && a.write)) continue;
    const fam = familyOf(a.name), w = wordsOf(a.name);
    const score = b => (fam && familyOf(b.name) === fam ? 100 : 0) + [...wordsOf(b.name)].filter(x => w.has(x)).length * 10;
    const pool = list.filter(b => b !== a && !b.asio && !b.loopback && !b.bluetooth && score(b) > 0);
    if (hw.isWrapper(a.name)) continue;   // ASIO4ALL & co. are not one device: no twin
    const pick = side => pool.filter(b => b[side]).sort((x, y) => score(y) - score(x))[0] || null;
    const fb = {};
    if (!a.read) { const b = pick('read'); if (b) { a.read = { ...b.read, fallback: 'wasapi' }; a.inputs = b.inputs; fb.input = b.name; } }
    if (!a.write) { const b = pick('write'); if (b) { a.write = { ...b.write, fallback: 'wasapi' }; a.outputs = b.outputs; fb.output = b.name; } }
    if (fb.input || fb.output) a.fallback = { via: 'wasapi', ...fb };
  }
  return list;
}

module.exports = { linkAsioFallback, probeReason, inferProbeFailed, untruncate, isBluetooth, btBase, isPrimary, groupInterfaces, keyOf, baseName, apiRank };
