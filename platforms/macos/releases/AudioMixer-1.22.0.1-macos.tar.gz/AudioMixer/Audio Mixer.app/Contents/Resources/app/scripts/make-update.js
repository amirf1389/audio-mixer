#!/usr/bin/env node
'use strict';
// Builds and signs releases/update.json (the OTA manifest) for the release files of the systems: <os>/releases/ (android, ios, windows, macos, linux; see layout.js).
//   node scripts/make-update.js [--dir <vendor key dir>] [--base <url where the files are served>] [--notes "a|b|c"]
// Default base: https://raw.githubusercontent.com/amirf1389/audio-mixer/main  (the files are committed in <os>/releases/, so a URL ends in .../<os>/releases/<file>).
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { signManifest } = require('../bridge/update');
const { keyFor, vendorDir } = require('./license');

const { ROOT, osOfKey, releasesRel, findRelease } = require('./layout');
const arg = (a, n, d) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : d; };

// `releases`: one flat folder that holds all the files (URLs are base/<file>); without it the files are looked up in <os>/releases/ and the URLs follow that layout,
// unless `flatUrls` is set (a server that serves every file from one /releases/ folder, see scripts/ota.js).
function build({ releases, flatUrls = false, version, base, notes = [], now = new Date() } = {}) {
  const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
  const want = {
    // the setup program: its name since the rename to AmF X1, then the one before it
    'win-x64-exe': [`AmF X1-${version}.exe`, `Audio Mixer-${version}.exe`], 'win-x64-msi': `AudioMixer-${version}-x64.msi`, 'win-x86-msi': `AudioMixer-${version}-x86.msi`,
    'linux-deb': `audio-mixer_${version}_all.deb`, 'linux-tar': `AudioMixer-${version}-linux.tar.gz`, 'macos': `AudioMixer-${version}-macos.tar.gz`, 'macos-dmg': `AudioMixer-${version}-macos.dmg`,
    'android-apk': `AudioMixer-${version}-android.apk`, 'ios-project': `AudioMixer-${version}-ios-xcode-project.tar.gz`,
    'win-asio-driver': `AudioMixer-${version}-asio-driver-windows.zip`,
    'win-x64-native': `AudioMixer-${version}-native-windows-x64.exe`, 'win-x86-native': `AudioMixer-${version}-native-windows-x86.exe`,   // audiomixer-native.exe --update
  };
  const files = {};
  for (const [key, names] of Object.entries(want)) {
    let name = null, f = null;
    for (const n of [].concat(names)) { const c = releases ? path.join(releases, n) : findRelease(n, osOfKey(key)); if (c && fs.existsSync(c)) { name = n; f = c; break; } }
    if (!f) continue;
    files[key] = { name, url: `${base}/${releases || flatUrls ? '' : releasesRel(key) + '/'}${encodeURIComponent(name)}`, size: fs.statSync(f).size, sha256: sha(f) };
  }
  if (!Object.keys(files).length) throw new Error('no release files for version ' + version + ' in ' + (releases || '<os>/releases'));
  return { product: 'audio-mixer', version, channel: 'stable', released: now.toISOString().slice(0, 10), notes, files };
}

if (require.main === module) (async () => {
  const a = process.argv.slice(2);
  try {
    const version = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
    const manifest = build({ version, base: arg(a, '--base', 'https://raw.githubusercontent.com/amirf1389/audio-mixer/main'), notes: String(arg(a, '--notes', '')).split('|').filter(Boolean) });
    const env = signManifest(manifest, await keyFor(vendorDir(a)));   // a locked key folder asks for the PIN
    fs.writeFileSync(path.join(ROOT, 'releases', 'update.json'), JSON.stringify(env, null, 2) + '\n');
    console.log(`releases/update.json signed: version ${version}, ${Object.keys(manifest.files).length} files`);
  } catch (e) { console.error('Error: ' + e.message); process.exit(1); }
})();
module.exports = { build };
