Audio Mixer 1.16.0 for Linux (any distribution)

1. Unpack:   tar xzf AudioMixer-1.16.0-linux.tar.gz && cd audio-mixer-1.16.0
2. Install:  sh install.sh        (as root: /opt/audio-mixer + /usr/local/bin; as a user: ~/.local/share/audio-mixer-app + ~/.local/bin)
   It downloads Node.js 18+ with npm when missing (official build, checksum verified, no administrator rights) and installs the native audio module.
3. Start:    audio-mixer           Commands: audio-mixer doctor | drivers | license | plugins | update | npm install audify | service install | uninstall
4. Remove:   audio-mixer uninstall   (or: sh uninstall.sh, run as the same user; --purge also removes the downloaded Node.js)

Debian / Ubuntu: use the audio-mixer_1.16.0_all.deb package instead (apt install ./audio-mixer_1.16.0_all.deb, remove with apt remove audio-mixer).
Downloaded drivers (~/AudioMixerDrivers), plugins (~/AudioMixerPlugins) and the license key are left in place.
