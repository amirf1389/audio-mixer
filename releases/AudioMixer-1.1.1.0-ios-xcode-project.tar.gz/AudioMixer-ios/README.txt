Audio Mixer 1.1.1.0 for iOS (Xcode project)

1. On a Mac with Xcode 14 or newer: brew install xcodegen
2. In this folder: xcodegen generate && open AudioMixer.xcodeproj
3. Xcode > AudioMixer target > Signing & Capabilities: choose your team, then Run on your iPhone / iPad (iOS 15+).

The app shows the mixer page bundled in www/ (served on 127.0.0.1 inside the app). PC-mode features (ASIO / WASAPI, plugins) need the PC.
