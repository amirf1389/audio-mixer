AmF X1 by AMFB Audio  -  Windows x64

  amixos.exe            the console (Qt 6 Quick): start this
  AmF X1.exe            the engine command line (--list-devices, --backend asio|wasapi|dsound, --update, --install-driver)
  amixos-daemon.exe     the engine as a local HTTP / WebSocket service for the Android remote (binds 127.0.0.1)
  AudioMixerASIO64.dll  the ASIO driver: register from an administrator prompt with  "AmF X1.exe" --install-driver
  Qt6*.dll, platforms\, imageformats\, qml\   the Qt 6.4.2 runtime (MinGW build) the console needs; keep them next to amixos.exe

Data goes to %APPDATA%\AMFB Audio\AmF X1, cache to %LOCALAPPDATA%\AMFB Audio\AmF X1 (see docs/install-layout.md in the repository).
These files are not signed; a release is signed with the vendor's certificate (scripts/sign-windows.js). Cross-built on Linux with mingw-w64
and the official Qt 6.4.2 MinGW kit; not yet run on a Windows PC from the build machine.
