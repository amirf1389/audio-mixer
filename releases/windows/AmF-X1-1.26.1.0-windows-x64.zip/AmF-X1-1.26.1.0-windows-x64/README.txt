AmF X1 by AMFB Audio 1.26.1.0 - Windows x64
  amixos.exe            the console (Qt 6 Quick): start this
  AmF X1.exe            the engine command line (--list-devices, --backend asio|wasapi|dsound, --update, --install-driver)
  AmF X1 Diagnostics.exe  the system check: speakers, headphones, microphones, ASIO drivers, a report
  AmF X1 Network.exe    the engine as a local HTTP / WebSocket service for the Android remote (binds 127.0.0.1)
  AudioMixerASIO64.dll  the ASIO driver: register from an administrator prompt with  "AmF X1.exe" --install-driver
  AudioMixerASIO32.dll  the 32-bit ASIO driver (32-bit host programs): register as administrator with  %WINDIR%\SysWOW64\regsvr32.exe AudioMixerASIO32.dll
  drivers\asio\         the Steinberg ASIO licence, usage guidelines and change list
  licenses\              third-party licences and the additional terms
  AmF X1 Extras         a separate setup (AmF-X1-Extras-1.26.1.0-setup.exe) into this folder: the Plug-in Builder and its VST3 shell, AmF X1 Hybrid,
                        the WEB STACK (web\: nginx, Node.js, the bridge, the browser remote) and the Steinberg ASIO usage guidelines
  Qt6*.dll, platforms\, imageformats\, qml\   the Qt 6.4.2 runtime (MinGW build) the console needs; keep them next to amixos.exe
Data goes to %APPDATA%\AMFB Audio\AmF X1, cache to %LOCALAPPDATA%\AMFB Audio\AmF X1 (docs/install-layout.md). Unsigned: sign with scripts/sign-windows.js.
