'use strict';
// Autostart ("enable") for the local system server: starts bridge/server.js when you log in, no admin rights needed.
//   macOS: LaunchAgent   Linux: systemd user service   Windows: not offered any more (status / uninstall still find and remove the Run entry of older versions)
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFile, spawn, spawnSync } = require('node:child_process');

const NAME = 'audio-mixer';
const SERVER = path.resolve(__dirname, '..', 'bridge', 'server.js');

// Paths end up inside quoted arguments of generated files: refuse anything that could break out of them.
function safePath(p) {
  if (typeof p !== 'string' || !p || /["'\r\n\0%$`]/.test(p)) throw new Error('path contains unsupported characters: ' + p);
  return p;
}
const xml = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]));

// The Run entry that older Windows versions wrote (only read and deleted now).
const WIN_RUN_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
const WIN_VALUE = 'AudioMixerServer';
const args = server => [].concat(server);
function macPlist(node, server, log) {
  return `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0">\n<dict>\n` +
    `  <key>Label</key><string>com.audiomixer.bridge</string>\n  <key>ProgramArguments</key>\n  <array><string>${xml(safePath(node))}</string>${args(server).map(a => `<string>${xml(safePath(a))}</string>`).join('')}</array>\n` +
    `  <key>RunAtLoad</key><true/>\n  <key>KeepAlive</key><true/>\n  <key>StandardOutPath</key><string>${xml(safePath(log))}</string>\n  <key>StandardErrorPath</key><string>${xml(safePath(log))}</string>\n</dict>\n</plist>\n`;
}
function systemdUnit(node, server) {
  return `[Unit]\nDescription=Audio Mixer local system server\nAfter=network.target\n\n[Service]\nExecStart="${safePath(node)}" ${args(server).map(a => `"${safePath(a)}"`).join(' ')}\nRestart=on-failure\n\n[Install]\nWantedBy=default.target\n`;
}

function targets(platform = process.platform, env = process.env, home = os.homedir()) {
  if (platform === 'win32') {
    return { platform, key: WIN_RUN_KEY, value: WIN_VALUE, file: WIN_RUN_KEY + '\\' + WIN_VALUE };
  }
  if (platform === 'darwin') return { platform, file: path.join(home, 'Library', 'LaunchAgents', 'com.audiomixer.bridge.plist'), log: path.join(home, 'Library', 'Logs', 'audio-mixer.log') };
  if (platform === 'linux') return { platform, file: path.join((env.XDG_CONFIG_HOME || path.join(home, '.config')), 'systemd', 'user', NAME + '.service') };
  throw new Error('autostart is not supported on ' + platform);
}

const run = (exec, cmd, args) => new Promise(res => exec(cmd, args, { windowsHide: true }, err => res(!err)));

// `opts` is injectable for tests: { platform, env, home, node, server, launcher, exec, spawn, reg }
async function install(opts = {}) {
  // single-file build (scripts/build-single.js): the executable (or the bundle run by node) is the server; --no-open keeps the browser closed at login
  const me = global.__AM_SELF && !opts.node && !opts.server ? global.__AM_SELF : null;
  const node = opts.node || process.execPath, server = opts.server || (me ? [...(me.script ? [me.script] : []), '--no-open'] : SERVER), exec = opts.exec || execFile;
  const t = targets(opts.platform, opts.env, opts.home);
  if (t.platform === 'win32') {
    // Start at login was removed on Windows (a Run-key entry that starts a program is one of the things antivirus heuristics flag): uninstall / status still
    // remove and report an entry left by an older version, and the setup program no longer writes one.
    throw new Error('Start at login is not offered on Windows any more. Start Audio Mixer from its Start Menu shortcut. To remove an entry left by an older version: audio-mixer service uninstall');
  }
  const content = t.platform === 'darwin' ? macPlist(node, server, t.log) : systemdUnit(node, server);
  fs.mkdirSync(path.dirname(t.file), { recursive: true });
  fs.writeFileSync(t.file, content, { mode: 0o644 });
  let started;
  if (t.platform === 'darwin') started = await run(exec, 'launchctl', ['load', '-w', t.file]);
  else { await run(exec, 'systemctl', ['--user', 'daemon-reload']); started = await run(exec, 'systemctl', ['--user', 'enable', '--now', NAME + '.service']); }
  return { file: t.file, started };
}

async function uninstall(opts = {}) {
  const exec = opts.exec || execFile, t = targets(opts.platform, opts.env, opts.home);
  if (t.platform === 'win32') {
    const existed = status(opts).installed;
    await run(exec, 'reg', ['delete', t.key, '/v', t.value, '/f']);
    return { file: t.file, removed: existed };
  }
  if (t.platform === 'darwin') await run(exec, 'launchctl', ['unload', '-w', t.file]);
  else if (t.platform === 'linux') await run(exec, 'systemctl', ['--user', 'disable', '--now', NAME + '.service']);
  const existed = fs.existsSync(t.file);
  try { fs.unlinkSync(t.file); } catch (_) { /* not installed */ }
  if (t.platform === 'linux') await run(exec, 'systemctl', ['--user', 'daemon-reload']);
  return { file: t.file, removed: existed };
}

function status(opts = {}) {
  const t = targets(opts.platform, opts.env, opts.home);
  if (t.platform === 'win32') {
    const q = (opts.reg || ((args) => spawnSync('reg', args, { windowsHide: true })))(['query', t.key, '/v', t.value]);
    return { file: t.file, installed: !!q && q.status === 0 };
  }
  return { file: t.file, installed: fs.existsSync(t.file) };
}

module.exports = { install, uninstall, status, targets, macPlist, systemdUnit, safePath };
