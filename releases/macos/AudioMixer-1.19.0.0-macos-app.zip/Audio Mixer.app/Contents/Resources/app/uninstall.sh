#!/bin/bash
# Removes Audio Mixer and its start-at-login entry. Downloaded drivers (~/AudioMixerDrivers) and plugins (~/AudioMixerPlugins) stay.
for DEST in /Applications "$HOME/Applications"; do
  APP="$DEST/Audio Mixer.app"
  if [ -d "$APP" ]; then
    NODE="$(command -v node 2>/dev/null || ls "$HOME/.local/share/audio-mixer/node/bin/node" /opt/homebrew/bin/node /usr/local/bin/node 2>/dev/null | head -1)"
    [ -n "$NODE" ] && "$NODE" "$APP/Contents/Resources/app/client/cli.js" service uninstall
    rm -rf "$APP" && echo "Removed $APP"
  fi
done
for L in /usr/local/bin/audio-mixer "$HOME/.local/bin/audio-mixer"; do   # the command line link, when it points into the app
  [ -L "$L" ] && case "$(readlink "$L")" in *"Audio Mixer.app"*) rm -f "$L" && echo "Removed $L" ;; esac
done
rm -f "$HOME/Library/LaunchAgents/com.audiomixer.bridge.plist"
rm -f "$HOME/Library/LaunchAgents/com.audiomixer.env.plist"; launchctl unsetenv AUDIO_MIXER_DIR 2>/dev/null
[ -f /etc/paths.d/audio-mixer ] && { echo "Removing /etc/paths.d/audio-mixer (asks for your password)"; sudo rm -f /etc/paths.d/audio-mixer; }
rm -rf "$HOME/.local/share/audio-mixer"   # the private Node.js and audio module that Audio Mixer downloaded
echo "Audio Mixer removed."
