Audio Mixer 1.5.1.0 for macOS

1. Install Node.js 18 or newer if you do not have it: https://nodejs.org/en/download
2. Double-click install.command (copies the app to /Applications, or ~/Applications).
   The app is not notarized: if macOS blocks it, right-click > Open once, or run: xattr -dr com.apple.quarantine "/Applications/Audio Mixer.app"
3. Start "Audio Mixer": the mixer opens in your browser. Start at login: answer y in install.command, or run the app's client with: service install

Files: app in /Applications/Audio Mixer.app, login item in ~/Library/LaunchAgents, downloaded drivers in ~/AudioMixerDrivers,
VST plugins are read from /Library/Audio/Plug-Ins/VST3 and ~/Library/Audio/Plug-Ins/VST3 (and ~/AudioMixerPlugins).
Remove everything with uninstall.command.
