#!/bin/bash
# Installs Audio Mixer: /Applications (or ~/Applications when you cannot write there). Double-click this file in Finder.
cd "$(dirname "$0")" || exit 1
DEST=/Applications
[ -w "$DEST" ] || DEST="$HOME/Applications"
mkdir -p "$DEST"
rm -rf "$DEST/Audio Mixer.app"
cp -R "Audio Mixer.app" "$DEST/" || { echo "Copy failed"; exit 1; }
xattr -dr com.apple.quarantine "$DEST/Audio Mixer.app" 2>/dev/null   # the app is not notarized
mkdir -p "$HOME/AudioMixerPlugins"
echo "Audio Mixer installed in $DEST"
APP="$DEST/Audio Mixer.app/Contents/Resources/app"
. "$APP/ensure-node.sh"
# Node.js 18+ and the native audio module are installed now if they are missing (official builds, checksum verified, no administrator rights)
if am_ensure_node; then
  am_ensure_audio "$APP"
  read -r -p "Start the local server when I log in? [y/N] " a
  if [ "$a" = "y" ] || [ "$a" = "Y" ]; then "$NODE" "$APP/client/cli.js" service install; fi
else
  echo "Node.js 18+ is not installed: https://nodejs.org/en/download (Audio Mixer asks again the first time it starts)."
fi
echo "Done. Open Audio Mixer from $DEST. Remove it later with uninstall.command."
