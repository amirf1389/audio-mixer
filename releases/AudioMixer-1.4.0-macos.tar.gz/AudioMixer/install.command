#!/bin/bash
# Installs Audio Mixer: /Applications (or ~/Applications when you cannot write there). Double-click this file in Finder.
cd "$(dirname "$0")" || exit 1
DEST=/Applications
[ -w "$DEST" ] || DEST="$HOME/Applications"
mkdir -p "$DEST"
rm -rf "$DEST/Audio Mixer.app"
cp -R "Audio Mixer.app" "$DEST/" || { echo "Copy failed"; exit 1; }
xattr -dr com.apple.quarantine "$DEST/Audio Mixer.app" 2>/dev/null   # the app is not notarized
mkdir -p "$HOME/AudioMixerPlugins"
echo "Audio Mixer installed in $DEST"
NODE="$(command -v node 2>/dev/null || ls /opt/homebrew/bin/node /usr/local/bin/node 2>/dev/null | head -1)"
if [ -z "$NODE" ]; then echo "Node.js 18+ is not installed yet: https://nodejs.org/en/download"; fi
read -r -p "Start the local server when I log in? [y/N] " a
if [ "$a" = "y" ] || [ "$a" = "Y" ]; then
  [ -n "$NODE" ] && "$NODE" "$DEST/Audio Mixer.app/Contents/Resources/app/client/cli.js" service install
fi
echo "Done. Open Audio Mixer from $DEST. Remove it later with uninstall.command."
