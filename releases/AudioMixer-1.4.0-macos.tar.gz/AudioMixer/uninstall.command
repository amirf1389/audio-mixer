#!/bin/bash
# Removes Audio Mixer and its start-at-login entry. Downloaded drivers (~/AudioMixerDrivers) and plugins (~/AudioMixerPlugins) stay.
for DEST in /Applications "$HOME/Applications"; do
  APP="$DEST/Audio Mixer.app"
  if [ -d "$APP" ]; then
    NODE="$(command -v node 2>/dev/null || ls /opt/homebrew/bin/node /usr/local/bin/node 2>/dev/null | head -1)"
    [ -n "$NODE" ] && "$NODE" "$APP/Contents/Resources/app/client/cli.js" service uninstall
    rm -rf "$APP" && echo "Removed $APP"
  fi
done
rm -f "$HOME/Library/LaunchAgents/com.audiomixer.bridge.plist"
echo "Audio Mixer removed."
