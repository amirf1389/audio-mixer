A mix OS 0.1.0 for Linux (x86_64)
  bin/amixos-daemon       the engine as a local HTTP / WebSocket service (binds 127.0.0.1; --allow-lan is unencrypted, use it only behind your own TLS proxy)
  lib/libamix.so          the C SDK (include/amix.h): offline mixer, live runtime (ALSA / null), meters, devices, licence
  perl/Audio-AmixOS       Perl XS module: AMIX_INC=../../include AMIX_LIB=../../lib perl Makefile.PL && make && make test
  sdk/wasm                the DSP core for browsers (amix_dsp.wasm + amix.mjs)
Install (program folder, the data stays inside it): sudo mkdir -p /opt/amf-x1 && sudo cp -r . /opt/amf-x1 && sudo chown -R  /opt/amf-x1/data /opt/amf-x1/cache
  then /opt/amf-x1/bin/amixos-daemon; data in /opt/amf-x1/data, cache in /opt/amf-x1/cache (install/layout.json; AMIX_DATA_DIR overrides)
Or system-wide libs: sudo cp lib/libamix.so* /usr/local/lib && sudo ldconfig && sudo cp include/amix.h /usr/local/include && sudo cp bin/amixos-daemon /usr/local/bin
The Qt console (amixos) is built from native/amixos with your distribution's Qt 6 (see the repository README).
