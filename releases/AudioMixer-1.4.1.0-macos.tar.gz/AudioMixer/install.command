#!/bin/bash
# Installs Audio Mixer: /Applications (or ~/Applications when you cannot write there). Double-click this file in Finder.
cd "$(dirname "$0")" || exit 1
DEST=/Applications
[ -w "$DEST" ] || DEST="$HOME/Applications"
mkdir -p "$DEST"
rm -rf "$DEST/Audio Mixer.app"
cp -R "Audio Mixer.app" "$DEST/" || { echo "Copy failed"; exit 1; }
xattr -dr com.apple.quarantine "$DEST/Audio Mixer.app" 2>/dev/null   # the app is not notarized
mkdir -p "$HOME/AudioMixerPlugins"
echo "Audio Mixer installed in $DEST"
APP="$DEST/Audio Mixer.app/Contents/Resources/app"
. "$APP/ensure-node.sh"
# Core Audio helper (Swift): lists the audio interfaces with channels and sample rates; optional, needs the Xcode command line tools
if command -v swiftc >/dev/null 2>&1 && [ -f "$APP/native/mac/AudioDevices.swift" ]; then
  swiftc -O -o "$APP/native/mac/AudioDevices" "$APP/native/mac/AudioDevices.swift" 2>/dev/null && echo "Core Audio helper built" || echo "Core Audio helper not built (system_profiler is used instead)"
fi
# Node.js 18+ and the native audio module are installed now if they are missing (official builds, checksum verified, no administrator rights)
if am_ensure_node; then
  am_ensure_audio "$APP"
  read -r -p "Start the local server when I log in? [y/N] " a
  if [ "$a" = "y" ] || [ "$a" = "Y" ]; then "$NODE" "$APP/client/cli.js" service install; fi
else
  echo "Node.js 18+ is not installed: https://nodejs.org/en/download (Audio Mixer asks again the first time it starts)."
fi
# the "audio-mixer" command (doctor, drivers, npm, setup, uninstall ...) on PATH
BINDIR=/usr/local/bin; [ -w "$BINDIR" ] || BINDIR="$HOME/.local/bin"
mkdir -p "$BINDIR" && ln -sf "$APP/audio-mixer" "$BINDIR/audio-mixer" && echo "Command line: $BINDIR/audio-mixer" || echo "Could not link the audio-mixer command."
case ":$PATH:" in *":$BINDIR:"*) ;; *) echo "Add $BINDIR to your PATH to use it:  echo 'export PATH="$BINDIR:$PATH"' >> ~/.zshrc" ;; esac
echo "Done. Open Audio Mixer from $DEST. Remove it later with uninstall.command (or: audio-mixer uninstall)."
