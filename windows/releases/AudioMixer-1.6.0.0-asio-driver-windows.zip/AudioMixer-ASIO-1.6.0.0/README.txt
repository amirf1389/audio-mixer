Audio Mixer ASIO driver 1.6.0.0

An ASIO driver (a DLL) that makes "Audio Mixer" appear in the ASIO driver list of DAWs, OBS and other ASIO programs.
   ASIO outputs (what the program plays)   -> the mixer reads them as an input source  (LIVE SOURCES: READ on the device "Audio Mixer")
   ASIO inputs  (what the program records) <- what the mixer sends to the device       (LIVE SOURCES: WRITE)
2 in / 2 out, 44.1 / 48 / 88.2 / 96 kHz, buffers of 64 to 2048 frames. Audio Mixer must be running (the driver keeps trying to connect every second).

Install (deliberately a separate step: the Audio Mixer setup program never installs a driver):
  1. Unpack this folder somewhere permanent (for example C:\Program Files\Audio Mixer ASIO). The DLLs are registered where they are.
  2. Right-click register.bat > Run as administrator. (It runs  regsvr32  on the DLLs: it writes HKLM\SOFTWARE\Classes\CLSID\{C1893F2F-1AD5-4344-9806-DCFD242C0D48}
     and HKLM\SOFTWARE\ASIO\Audio Mixer, nothing else.)
  3. Start Audio Mixer, then choose "Audio Mixer" as the ASIO driver in your program. Its control panel button shows whether the mixer is connected.
Remove: unregister.bat as administrator, then delete the folder.

The 64-bit DLL is for 64-bit programs, the 32-bit DLL for 32-bit programs; register both if you use both.
Not signed. Windows may warn when a DLL from the internet is registered; check the SHA-256 in the release.
Not tested on a real ASIO host in this release: the DLL was cross-compiled and checked structurally (exports, imports, interface layout).
"ASIO" is a trademark of Steinberg Media Technologies GmbH. The interface was implemented from its published description; no Steinberg SDK file is included.
