#!/bin/sh
# Removes Audio Mixer that install.sh put in place (run it as the same user): the program, the command, the menu entry and the start-at-login entry.
# Downloaded drivers (~/AudioMixerDrivers), plugins (~/AudioMixerPlugins) and the license key stay. --purge also removes the private Node.js and audio
# module that Audio Mixer downloaded into ~/.local/share/audio-mixer.
HERE="$(cd "$(dirname "$0")" && pwd)"
NODE="$(command -v node 2>/dev/null || ls "$HOME/.local/share/audio-mixer/node/bin/node" 2>/dev/null | head -1)"
[ -n "$NODE" ] && [ -f "$HERE/client/cli.js" ] && "$NODE" "$HERE/client/cli.js" service uninstall >/dev/null 2>&1
for B in /usr/local/bin/audio-mixer "$HOME/.local/bin/audio-mixer"; do
  [ -L "$B" ] && case "$(readlink "$B")" in "$HERE"/*) rm -f "$B" && echo "Removed $B" ;; esac
done
rm -f /usr/share/applications/audio-mixer.desktop "$HOME/.local/share/applications/audio-mixer.desktop" 2>/dev/null
[ "${1:-}" = "--purge" ] && rm -rf "$HOME/.local/share/audio-mixer" && echo "Removed the downloaded Node.js and audio module."
case "$HERE" in
  /opt/audio-mixer|"$HOME"/.local/share/audio-mixer-app) cd / && rm -rf "$HERE" && echo "Removed $HERE" ;;
  *) echo "Not removed (not an install.sh location): $HERE" ;;
esac
echo "Audio Mixer removed."
