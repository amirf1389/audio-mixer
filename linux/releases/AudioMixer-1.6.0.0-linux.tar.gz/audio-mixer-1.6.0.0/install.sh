#!/bin/sh
# Installs Audio Mixer on any Linux distribution: as root into /opt/audio-mixer (command in /usr/local/bin, menu entry for everyone), otherwise into
# ~/.local/share/audio-mixer-app (command in ~/.local/bin, menu entry for you). Node.js 18+ with npm is downloaded when missing (official build from
# nodejs.org, checksum verified, into ~/.local/share/audio-mixer, no administrator rights) and the native audio module (Audify) is installed.
#   sh install.sh [--yes]        --yes: no questions (also AUDIO_MIXER_YES=1);  AUDIO_MIXER_NO_NATIVE=1 skips the audio module
set -e
cd "$(dirname "$0")"
[ "${1:-}" = "--yes" ] && export AUDIO_MIXER_YES=1
if [ "$(id -u)" = 0 ]; then DEST=/opt/audio-mixer; BIN=/usr/local/bin; APPS=/usr/share/applications
else DEST="$HOME/.local/share/audio-mixer-app"; BIN="$HOME/.local/bin"; APPS="$HOME/.local/share/applications"; fi
rm -rf "$DEST"; mkdir -p "$DEST" "$BIN" "$APPS"
cp -R app/. "$DEST/"
chmod 755 "$DEST/audio-mixer" "$DEST/uninstall.sh" "$DEST/client/cli.js" "$DEST/bridge/server.js"
ln -sf "$DEST/audio-mixer" "$BIN/audio-mixer"
cat > "$APPS/audio-mixer.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Audio Mixer
Comment=Virtual mixing console with a local server for ASIO, ALSA, JACK and PipeWire audio
Exec=$DEST/audio-mixer
Icon=audio-card
Terminal=false
Categories=AudioVideo;Audio;Mixer;
Keywords=mixer;audio;asio;jack;pipewire;
DESK
mkdir -p "$HOME/AudioMixerPlugins"
echo "Audio Mixer installed in $DEST  (command: $BIN/audio-mixer)"
. "$DEST/ensure-node.sh"
if am_ensure_node; then
  am_ensure_audio "$DEST"
  if am_ask "Start the local server when I log in?"; then "$NODE" "$DEST/client/cli.js" service install || true; fi
else
  echo "Node.js 18+ is not installed: https://nodejs.org/en/download (Audio Mixer asks again the first time it starts)."
fi
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Add $BIN to your PATH to use the command:  echo 'export PATH="$BIN:$PATH"' >> ~/.profile" ;; esac
echo "Start it with: audio-mixer    Commands: audio-mixer doctor | drivers | npm | uninstall    Remove it with: sh $DEST/uninstall.sh"
