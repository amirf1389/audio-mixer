# Audio Mixer: where it is installed (read by login shells)
[ -d /opt/audio-mixer ] && export AUDIO_MIXER_DIR=/opt/audio-mixer
