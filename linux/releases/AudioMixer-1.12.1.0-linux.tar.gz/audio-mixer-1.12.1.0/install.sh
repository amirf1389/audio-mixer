#!/bin/sh
# Installs Audio Mixer on any Linux distribution: as root into /opt/audio-mixer (command in /usr/local/bin, menu entry for everyone), otherwise into
# ~/.local/share/audio-mixer-app (command in ~/.local/bin, menu entry for you). Node.js 18+ with npm is downloaded when missing (official build from
# nodejs.org, checksum verified, into ~/.local/share/audio-mixer, no administrator rights) and the native audio module (Audify) is installed.
#   sh install.sh [--yes]        --yes: no questions (also AUDIO_MIXER_YES=1);  AUDIO_MIXER_NO_NATIVE=1 skips the audio module
set -e
cd "$(dirname "$0")"
[ "${1:-}" = "--yes" ] && export AUDIO_MIXER_YES=1
if [ "$(id -u)" = 0 ]; then DEST=/opt/audio-mixer; BIN=/usr/local/bin; APPS=/usr/share/applications
else DEST="$HOME/.local/share/audio-mixer-app"; BIN="$HOME/.local/bin"; APPS="$HOME/.local/share/applications"; fi
rm -rf "$DEST"; mkdir -p "$DEST" "$BIN" "$APPS"
cp -R app/. "$DEST/"
chmod 755 "$DEST/audio-mixer" "$DEST/uninstall.sh" "$DEST/client/cli.js" "$DEST/bridge/server.js"
ln -sf "$DEST/audio-mixer" "$BIN/audio-mixer"
cat > "$APPS/audio-mixer.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Audio Mixer
Comment=Virtual mixing console with a local server for ASIO, ALSA, JACK and PipeWire audio
Exec=$DEST/audio-mixer
Icon=audio-card
Terminal=false
Categories=AudioVideo;Audio;Mixer;
Keywords=mixer;audio;asio;jack;pipewire;
DESK
cat > "$APPS/audio-mixer-open.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Audio Mixer (open a scene file or link)
Exec=$BIN/audio-mixer open %u
Icon=audio-card
Terminal=false
NoDisplay=true
MimeType=application/x-audio-mixer-scene;x-scheme-handler/audiomixer;
DESK
# environment, file type and link handler in the system's own places (nothing in your shell start-up files is edited):
#   root: /etc/profile.d (login shells), /usr/lib/environment.d (systemd user sessions), /usr/share/mime;  user: ~/.config/environment.d (also puts $BIN on PATH there), ~/.local/share/mime
if [ "$(id -u)" = 0 ]; then
  mkdir -p /etc/profile.d /usr/lib/environment.d; MIMEDIR=/usr/share/mime
  printf '# Audio Mixer: where it is installed (read by login shells)\n[ -d %s ] && export AUDIO_MIXER_DIR=%s\n' "$DEST" "$DEST" > /etc/profile.d/audio-mixer.sh
  printf 'AUDIO_MIXER_DIR=%s\n' "$DEST" > /usr/lib/environment.d/60-audio-mixer.conf
else
  mkdir -p "$HOME/.config/environment.d"; MIMEDIR="$HOME/.local/share/mime"
  printf 'AUDIO_MIXER_DIR=%s\nPATH=%s:${PATH}\n' "$DEST" "$BIN" > "$HOME/.config/environment.d/60-audio-mixer.conf"
fi
mkdir -p "$MIMEDIR/packages"
cat > "$MIMEDIR/packages/audio-mixer.xml" <<'MIMEXML'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-audio-mixer-scene">
    <comment>Audio Mixer scene archive</comment>
    <glob pattern="*.amix"/>
    <sub-class-of type="application/json"/>
  </mime-type>
</mime-info>
MIMEXML
command -v update-mime-database >/dev/null 2>&1 && update-mime-database "$MIMEDIR" >/dev/null 2>&1 || true
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" >/dev/null 2>&1 || true
mkdir -p "$HOME/AudioMixerPlugins"
echo "Audio Mixer installed in $DEST  (command: $BIN/audio-mixer)"
. "$DEST/ensure-node.sh"
if am_ensure_node; then
  am_ensure_audio "$DEST"
  if am_ask "Start the local server when I log in?"; then "$NODE" "$DEST/client/cli.js" service install || true; fi
else
  echo "Node.js 18+ is not installed: https://nodejs.org/en/download (Audio Mixer asks again the first time it starts)."
fi
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Add $BIN to your PATH to use the command:  echo 'export PATH="$BIN:$PATH"' >> ~/.profile" ;; esac
echo "Start it with: audio-mixer    Commands: audio-mixer doctor | drivers | npm | uninstall    Remove it with: sh $DEST/uninstall.sh"
